package sort;

import sort.Helper;

public class SelectionSort<X extends Comparable<X>> implements Sort<X> {

	@Override
	public void sort(X[] xs, int from, int to) {
		for (int i = from; i < to; i++) {
			int min = i;
			for (int j = i; j < to; j++) {
				if (Helper.less(xs[j], xs[min])) {
					min = j;
				}
			}
			Helper.swap(xs, i, min);
		}
	}
}

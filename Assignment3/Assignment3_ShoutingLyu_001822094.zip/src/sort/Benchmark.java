package sort;

import java.util.function.Function;
public class Benchmark<T> {
	public Benchmark(Function<T, Void> f) {
        this.f = f;
    }

    public double run(T t, int n) {
 
    	for(int i=0;i<10;i++) {
    		f.apply(t);
    	}
    	
    	long start = System.nanoTime();
    	for(int i=0;i<n;i++) {
    		f.apply(t);
    	}
    	long end = System.nanoTime();
    	long runtime = (end-start);
    	double average = runtime/n;
        return average;  
    }

    private final Function<T, Void> f;

    public static void main(String[] args) {
        int m = 100; 
        Integer[] array = new Integer[10000];
        for (int i = 0; i < 10000; i++) array[i] = i; 
        int n = 50;

        for(int i=0;i<6;i++) {
        	n = n*2;
        	benchmarkSort(array, n, "InsertionSort", new InsertionSort<>(), m);
        	benchmarkSort(array, n, "SelectionSort", new SelectionSort<>(), m);
        }
    }

    private static void benchmarkSort(Integer[] xs, Integer n, String name, Sort<Integer> sorter, int m) {
        Function<Integer, Void> sortFunction = (x) -> {
//        	Helper.randomShuffle(xs, 0, x);
        	Helper.reverseShuffle(xs,0,x);
//        	Helper.partialShuffle(xs, 0, x);
//			No Shuffle
        	sorter.sort(xs, 0, x);
            return null;
        };
        
        Benchmark<Integer> bm = new Benchmark<>(sortFunction);
        double x = bm.run(n, m);
        System.out.println(name + ": " + x + " nanoseconds for n=" + n);
    }
    

}

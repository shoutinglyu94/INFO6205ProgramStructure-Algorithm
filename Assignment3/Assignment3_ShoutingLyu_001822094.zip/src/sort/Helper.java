package sort;

import java.util.Random;

public class Helper {

	static <X extends Comparable<X>> boolean less(X v, X w) {
		return v.compareTo(w) < 0;
	}

	static <X extends Comparable<X>> void swap(X[] a, int i, int j) {
		X temp = a[i];
		a[i] = a[j];
		a[j] = temp;
	}

	static <X extends Comparable<X>> void randomShuffle(X[] a, int start, int end) {
		for (int i = start; i < end; i++) {
			int j = new Random().nextInt(i + 1);
			swap(a, i, j);
		}
	}

	static <X extends Comparable<X>> void reverseShuffle(X[] a, int start, int end) {
		int N = end - start;
		int mid = N / 2;
		for (int i = 0; i < mid; i++) {
			swap(a, i, N - i - 1);
		}
	}

	static <X extends Comparable<X>> void partialShuffle(X[] a, int start, int end) {
		for (int i = start; i < end / 2; i++) {
			int j = new Random().nextInt(i + 1);
			swap(a, i, j);
		}
	}
}
